# Beyond The Horizons

A responsive travel-planning website that helps families and friends discover destinations, compare travel packages, submit enquiries, and get in touch with travel specialists. This README reflects the Part 3 submission (Functionality & SEO).

---

## Table of Contents
1. [Project Overview](#project-overview)  
2. [Live Features](#live-features)  
3. [Tech Stack](#tech-stack)  
4. [Project Structure](#project-structure)  
5. [Getting Started](#getting-started)  
6. [Part 3 Enhancements](#part-3-enhancements)  
7. [Testing Checklist](#testing-checklist)  
8. [SEO & Compliance](#seo--compliance)  
9. [References](#references)  
10. [Changelog](#changelog)  
11. [Submission Notes](#submission-notes)

---

## Project Overview
Beyond The Horizons is a six-page static site (`index`, `about`, `destinations`, `packages`, `enquiry`, `contact`). Part 3 focused on JavaScript-driven interactivity, form validation, and SEO best practices. Users can:
- Browse hero offers, destinations, packages, and contact details.
- Filter destinations by category, view seasonal deals, and compare packages.
- Submit booking enquiries and contact messages with client-side validation.
- Explore office locations via an interactive map.
- Experience lightbox galleries, accordions, and smooth animations.

---

## Live Features

| Page             | Key Features                                                                 |
|------------------|------------------------------------------------------------------------------|
| `index.html`     | Hero search UI, special offers, top categories                              |
| `about.html`     | Company story, mission/vision, team, metrics                                |
| `destinations.html` | Category tabs, featured cards, seasonal deals, lightbox gallery          |
| `packages.html`  | Package categories, comparison table, dynamic forms                         |
| `enquiry.html`   | Multi-section booking form with validation & pricing modal                  |
| `contact.html`   | Contact info, map, FAQ accordion, message form with email helper            |

---

## Tech Stack
- **HTML5** – semantic markup per page  
- **CSS3** – custom design with responsive grid and animation  
- **JavaScript (Vanilla ES6)** – tabs, accordion, lightbox, modals, dynamic filtering, form validation, Leaflet map  
- **Leaflet.js + OpenStreetMap** – interactive office map

No external build tools are required; everything runs in the browser.

---

## Project Structure
```
Beyond-Horizons/
├── index.html
├── about.html
├── destinations.html
├── packages.html
├── enquiry.html
├── contact.html
├── css/
│   └── styles.css
├── js/
│   ├── main.js
│   ├── forms.js
│   └── maps.js
├── images/
│   ├── logo.jpg, logo-32.png, logo-192.png
│   └── destinations/...
├── robots.txt
└── sitemap.xml
```

---

## Getting Started
1. **Clone / Download**
  
   git clone <repo-url>
   cd Beyond-Horizons
  2. **Open Locally**
   - Double-click `index.html`, or use VS Code Live Server / `python -m http.server`.
   - Ensure folder structure remains intact so CSS/JS paths resolve.
3. **Browser Support**
   - Tested on Chrome, Edge, and Firefox.

---

## Part 3 Enhancements

| Feature | Description |
|---------|-------------|
| Tabs & Filters | Destination categories toggle visible cards with fade animations. |
| Lightbox Gallery | Clicking destination images opens a modal gallery with navigation. |
| FAQ Accordion | Contact page FAQ uses keyboard-accessible accordion panels. |
| Modals | Enquiry/Contact forms display modal confirmations (quotes, email preview). |
| Form Validation | Real-time validation with custom errors, date logic, phone/email checks. |
| Availability Simulation | Enquiry form estimates cost & availability with async feedback. |
| Leaflet Map | Contact page map auto-loads markers for Johannesburg & Cape Town. |
| Animations | Intersection Observer drives “fade-in” reveals for cards and sections. |
| Dynamic Buttons | “Load more” simulation with disabled states and loading text. |
| SEO Assets | Unique meta tags per page, Open Graph/Twitter data, canonical links, robots.txt, sitemap.xml. |

---

## Testing Checklist
1. **Interactive UI**
   - Tabs filter cards correctly.
   - Accordion opens/closes with keyboard support.
   - Lightbox opens/closes, arrow keys navigate.
   - Smooth scrolling works for anchor links.
2. **Forms**
   - Required fields show inline errors.
   - Email/phone/date validation enforced.
   - Enquiry form modal shows price/availability.
   - Contact form modal generates email body + copy/open buttons.
3. **Map**
   - Leaflet tiles load; markers show popups for both offices.
4. **Responsive Layout**
   - Test 1200px, 992px, 768px, 576px breakpoints.
5. **Console/Network**
   - No JavaScript errors.
   - CSS/JS files load (status 200).
   - Leaflet assets fetched only once map is visible.

---

## SEO & Compliance
- `robots.txt` permits public pages, references sitemap, sets crawl delay.
- `sitemap.xml` lists all HTML pages with last modified dates.
- Each page includes title, description, keywords, author, robots, Open Graph/Twitter tags, canonical link, and favicons.

---

## References
- **Images**  
  - Destination images (Bali, Paris, Tokyo, New York, Santorini, Costa Rica, Cape Town, Durban, Kruger Park, Garden Route, Drakensberg) sourced from royalty-free stock libraries (Unsplash & Pexels) and stored locally in `images/destinations/`.
- **Map**  
  - [Leaflet.js](https://leafletjs.com/) for interactive mapping (MIT License).  
  - Map tiles © [OpenStreetMap contributors](https://www.openstreetmap.org/copyright).
- **Icons / Favicons**  
  - Custom Beyond The Horizons logo variations (`logo.jpg`, `logo-32.png`, `logo-192.png`).
- **Fonts & Inspiration**  
  - Native system fonts via CSS stack; UI inspiration from modern travel-agency designs.

---

## Changelog

### Part 3 (2025-11-15)
- Added `js/main.js`, `js/forms.js`, `js/maps.js`.
- Implemented destination tabs, lightbox, FAQ accordion, modal system, smooth scroll, load-more simulation.
- Built comprehensive form validation & modal feedback for enquiry/contact pages.
- Integrated Leaflet map with markers and service radius overlay.
- Enhanced `css/styles.css` with new components, animations, and responsive improvements.
- Added SEO assets (`robots.txt`, `sitemap.xml`) and updated meta tags on all pages.