/* ============================================
   Beyond The Horizons - Main JavaScript File
   Part 3: Interactive Elements & Functionality
   ============================================ */

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    initTabs();
    initAccordion();
    initModals();
    initLightbox();
    initSearchFilter();
    initAnimations();
    initFormValidation();
    initDynamicContent();
});

/* ============================================
   TABS FUNCTIONALITY (Destinations Page)
   ============================================ */
function initTabs() {
    const tabButtons = document.querySelectorAll('.tab-button');
    const destinationCards = document.querySelectorAll('.destination-card');

    if (tabButtons.length === 0) return;

    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            tabButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            this.classList.add('active');

            const category = this.textContent.trim().toLowerCase();
            filterDestinations(category);
        });
    });

    function filterDestinations(category) {
        destinationCards.forEach(card => {
            if (category === 'all destinations') {
                card.style.display = 'block';
                fadeIn(card);
            } else {
                // Check if card matches category (you can add data attributes to cards)
                const cardText = card.textContent.toLowerCase();
                const categoryMap = {
                    'beach getaways': ['bali', 'santorini', 'durban', 'capetown'],
                    'city breaks': ['paris', 'tokyo', 'new york'],
                    'adventure tours': ['costa rica', 'kruger', 'drakensberg'],
                    'cultural experiences': ['paris', 'tokyo', 'bali', 'garden route']
                };

                const matches = categoryMap[category]?.some(term => 
                    cardText.includes(term)
                ) || false;

                if (matches) {
                    card.style.display = 'block';
                    fadeIn(card);
                } else {
                    fadeOut(card, () => {
                        card.style.display = 'none';
                    });
                }
            }
        });
    }
}

/* ============================================
   ACCORDION FUNCTIONALITY (FAQ Section)
   ============================================ */
function initAccordion() {
    const faqItems = document.querySelectorAll('.faq-item');

    faqItems.forEach(item => {
        const question = item.querySelector('h3');
        const answer = item.querySelector('p');

        if (question && answer) {
            // Initially hide answers
            answer.style.display = 'none';
            answer.style.maxHeight = '0';
            answer.style.overflow = 'hidden';
            answer.style.transition = 'max-height 0.3s ease-out, padding 0.3s ease-out';

            // Add click handler
            question.style.cursor = 'pointer';
            question.setAttribute('aria-expanded', 'false');
            question.setAttribute('role', 'button');
            question.setAttribute('tabindex', '0');

            question.addEventListener('click', function() {
                const isExpanded = this.getAttribute('aria-expanded') === 'true';
                
                // Close all other items
                faqItems.forEach(otherItem => {
                    if (otherItem !== item) {
                        const otherAnswer = otherItem.querySelector('p');
                        const otherQuestion = otherItem.querySelector('h3');
                        if (otherAnswer && otherQuestion) {
                            otherAnswer.style.maxHeight = '0';
                            otherAnswer.style.paddingTop = '0';
                            otherAnswer.style.paddingBottom = '0';
                            otherQuestion.setAttribute('aria-expanded', 'false');
                            otherQuestion.classList.remove('active');
                        }
                    }
                });

                // Toggle current item
                if (isExpanded) {
                    answer.style.maxHeight = '0';
                    answer.style.paddingTop = '0';
                    answer.style.paddingBottom = '0';
                    this.setAttribute('aria-expanded', 'false');
                    this.classList.remove('active');
                } else {
                    answer.style.display = 'block';
                    answer.style.maxHeight = answer.scrollHeight + 'px';
                    answer.style.paddingTop = '12px';
                    answer.style.paddingBottom = '12px';
                    this.setAttribute('aria-expanded', 'true');
                    this.classList.add('active');
                }
            });

            // Keyboard support
            question.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    this.click();
                }
            });
        }
    });
}

/* ============================================
   MODAL FUNCTIONALITY
   ============================================ */
function initModals() {
    // Create modal container if it doesn't exist
    if (!document.querySelector('.modal-overlay')) {
        const modalHTML = `
            <div class="modal-overlay" id="modalOverlay" aria-hidden="true">
                <div class="modal-container">
                    <button class="modal-close" aria-label="Close modal">&times;</button>
                    <div class="modal-content"></div>
                </div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', modalHTML);
    }

    const modalOverlay = document.getElementById('modalOverlay');
    const modalClose = document.querySelector('.modal-close');
    const modalContent = document.querySelector('.modal-content');

    // Close modal function
    function closeModal() {
        modalOverlay.setAttribute('aria-hidden', 'true');
        modalOverlay.classList.remove('active');
        document.body.style.overflow = '';
    }

    // Open modal function
    window.openModal = function(content) {
        modalContent.innerHTML = content;
        modalOverlay.setAttribute('aria-hidden', 'false');
        modalOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
        modalClose.focus();
    };

    // Close on button click
    if (modalClose) {
        modalClose.addEventListener('click', closeModal);
    }

    // Close on overlay click
    if (modalOverlay) {
        modalOverlay.addEventListener('click', function(e) {
            if (e.target === modalOverlay) {
                closeModal();
            }
        });
    }

    // Close on Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && modalOverlay.classList.contains('active')) {
            closeModal();
        }
    });
}

/* ============================================
   LIGHTBOX GALLERY
   ============================================ */
function initLightbox() {
    // Create lightbox container
    if (!document.querySelector('.lightbox-overlay')) {
        const lightboxHTML = `
            <div class="lightbox-overlay" id="lightboxOverlay" aria-hidden="true">
                <button class="lightbox-close" aria-label="Close lightbox">&times;</button>
                <button class="lightbox-prev" aria-label="Previous image">&#8249;</button>
                <button class="lightbox-next" aria-label="Next image">&#8250;</button>
                <div class="lightbox-content">
                    <img class="lightbox-image" src="" alt="">
                    <div class="lightbox-caption"></div>
                </div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', lightboxHTML);
    }

    const lightboxOverlay = document.getElementById('lightboxOverlay');
    const lightboxImage = document.querySelector('.lightbox-image');
    const lightboxCaption = document.querySelector('.lightbox-caption');
    const lightboxClose = document.querySelector('.lightbox-close');
    const lightboxPrev = document.querySelector('.lightbox-prev');
    const lightboxNext = document.querySelector('.lightbox-next');

    let currentImages = [];
    let currentIndex = 0;

    // Get all gallery images
    const galleryImages = document.querySelectorAll('.destination-media img, .package-thumb, .story-image img');

    galleryImages.forEach((img, index) => {
        img.style.cursor = 'pointer';
        img.addEventListener('click', function() {
            openLightbox(index);
        });
    });

    function openLightbox(index) {
        // Collect all images
        currentImages = Array.from(galleryImages);
        currentIndex = index;

        if (currentImages.length === 0) return;

        updateLightboxImage();
        lightboxOverlay.setAttribute('aria-hidden', 'false');
        lightboxOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function updateLightboxImage() {
        if (currentImages[currentIndex]) {
            const img = currentImages[currentIndex];
            lightboxImage.src = img.src;
            lightboxImage.alt = img.alt || 'Gallery image';
            lightboxCaption.textContent = img.alt || '';
        }
    }

    function closeLightbox() {
        lightboxOverlay.setAttribute('aria-hidden', 'true');
        lightboxOverlay.classList.remove('active');
        document.body.style.overflow = '';
    }

    function nextImage() {
        currentIndex = (currentIndex + 1) % currentImages.length;
        updateLightboxImage();
    }

    function prevImage() {
        currentIndex = (currentIndex - 1 + currentImages.length) % currentImages.length;
        updateLightboxImage();
    }

    // Event listeners
    if (lightboxClose) lightboxClose.addEventListener('click', closeLightbox);
    if (lightboxPrev) lightboxPrev.addEventListener('click', prevImage);
    if (lightboxNext) lightboxNext.addEventListener('click', nextImage);

    if (lightboxOverlay) {
        lightboxOverlay.addEventListener('click', function(e) {
            if (e.target === lightboxOverlay) {
                closeLightbox();
            }
        });
    }

    // Keyboard navigation
    document.addEventListener('keydown', function(e) {
        if (lightboxOverlay.classList.contains('active')) {
            if (e.key === 'Escape') closeLightbox();
            if (e.key === 'ArrowRight') nextImage();
            if (e.key === 'ArrowLeft') prevImage();
        }
    });
}

/* ============================================
   SEARCH & FILTER FUNCTIONALITY
   ============================================ */
function initSearchFilter() {
    // Add search functionality to destinations page
    const searchInput = document.querySelector('#destination-search');
    if (searchInput) {
        searchInput.addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            const cards = document.querySelectorAll('.destination-card');

            cards.forEach(card => {
                const cardText = card.textContent.toLowerCase();
                if (cardText.includes(searchTerm)) {
                    card.style.display = 'block';
                    fadeIn(card);
                } else {
                    fadeOut(card, () => {
                        card.style.display = 'none';
                    });
                }
            });
        });
    }

    // Filter packages by type
    const packageFilters = document.querySelectorAll('.package-filter');
    packageFilters.forEach(filter => {
        filter.addEventListener('change', function() {
            const filterValue = this.value;
            const packageItems = document.querySelectorAll('.package-item, .category-card');

            packageItems.forEach(item => {
                if (filterValue === 'all' || item.dataset.type === filterValue) {
                    item.style.display = 'block';
                    fadeIn(item);
                } else {
                    fadeOut(item, () => {
                        item.style.display = 'none';
                    });
                }
            });
        });
    });
}

/* ============================================
   ANIMATIONS & TRANSITIONS
   ============================================ */
function initAnimations() {
    // Fade in on scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in-visible');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // Observe cards and sections
    const animatedElements = document.querySelectorAll(
        '.destination-card, .offer-card, .category-card, .value-card, .team-member, .stat-card'
    );

    animatedElements.forEach(el => {
        el.classList.add('fade-in');
        observer.observe(el);
    });

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href !== '#' && href.length > 1) {
                const target = document.querySelector(href);
                if (target) {
                    e.preventDefault();
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            }
        });
    });
}

// Fade in helper
function fadeIn(element) {
    element.style.opacity = '0';
    element.style.transition = 'opacity 0.3s ease-in';
    setTimeout(() => {
        element.style.opacity = '1';
    }, 10);
}

// Fade out helper
function fadeOut(element, callback) {
    element.style.transition = 'opacity 0.3s ease-out';
    element.style.opacity = '0';
    setTimeout(() => {
        if (callback) callback();
    }, 300);
}

/* ============================================
   DYNAMIC CONTENT LOADING
   ============================================ */
function initDynamicContent() {
    // Simulate dynamic loading of packages/destinations
    const loadMoreButton = document.querySelector('.load-more-btn');
    
    if (loadMoreButton) {
        loadMoreButton.addEventListener('click', function() {
            this.textContent = 'Loading...';
            this.disabled = true;

            // Simulate API call
            setTimeout(() => {
                // In a real application, this would fetch data from an API
                this.textContent = 'Load More';
                this.disabled = false;
                // Add new content here
            }, 1000);
        });
    }
}

/* ============================================
   FORM VALIDATION (Called from forms.js)
   ============================================ */
function initFormValidation() {
    // This will be handled by forms.js
    // Just a placeholder to ensure forms.js is loaded
    if (typeof validateEnquiryForm !== 'undefined') {
        console.log('Form validation initialized');
    }
}

