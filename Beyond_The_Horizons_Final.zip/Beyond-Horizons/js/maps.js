/* ============================================
   Beyond The Horizons - Interactive Maps
   Part 3: Location-based Features using Leaflet
   ============================================ */

// Initialize maps when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    initMaps();
});

function initMaps() {
    // Check if Leaflet is loaded
    if (typeof L === 'undefined') {
        console.warn('Leaflet library not loaded. Loading from CDN...');
        loadLeafletLibrary();
        return;
    }

    // Initialize office location maps
    const mapContainer = document.querySelector('.map-container');
    if (mapContainer) {
        createOfficeMap(mapContainer);
    }
}

function loadLeafletLibrary() {
    // Load Leaflet CSS
    const leafletCSS = document.createElement('link');
    leafletCSS.rel = 'stylesheet';
    leafletCSS.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
    leafletCSS.integrity = 'sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=';
    leafletCSS.crossOrigin = '';
    document.head.appendChild(leafletCSS);

    // Load Leaflet JS
    const leafletJS = document.createElement('script');
    leafletJS.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
    leafletJS.integrity = 'sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=';
    leafletJS.crossOrigin = '';
    leafletJS.onload = function() {
        initMaps(); // Retry initialization after library loads
    };
    document.body.appendChild(leafletJS);
}

function createOfficeMap(container) {
    // Replace placeholder with actual map container
    const placeholder = container.querySelector('.map-placeholder');
    if (placeholder) {
        placeholder.style.display = 'none';
    }

    // Create map div
    const mapDiv = document.createElement('div');
    mapDiv.id = 'officeMap';
    mapDiv.style.width = '100%';
    mapDiv.style.height = '400px';
    mapDiv.style.borderRadius = '12px';
    mapDiv.style.overflow = 'hidden';
    container.appendChild(mapDiv);

    // Initialize map centered on Johannesburg (main office)
    const map = L.map('officeMap').setView([-26.2041, 28.0473], 6);

    // Add OpenStreetMap tiles
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19
    }).addTo(map);

    // Add markers for office locations
    const johannesburgOffice = L.marker([-26.2041, 28.0473]).addTo(map);
    johannesburgOffice.bindPopup(`
        <div style="text-align: center;">
            <h3 style="margin: 0 0 8px 0; font-size: 16px; font-weight: bold;">Head Office</h3>
            <p style="margin: 4px 0; font-size: 14px;">58 West Street</p>
            <p style="margin: 4px 0; font-size: 14px;">Johannesburg, 2000</p>
            <p style="margin: 4px 0; font-size: 14px;">South Africa</p>
            <p style="margin: 8px 0 0 0; font-size: 14px;"><strong>Phone:</strong> +27 (11) 123-4567</p>
        </div>
    `).openPopup();

    const capeTownOffice = L.marker([-33.9249, 18.4241]).addTo(map);
    capeTownOffice.bindPopup(`
        <div style="text-align: center;">
            <h3 style="margin: 0 0 8px 0; font-size: 16px; font-weight: bold;">Branch Office</h3>
            <p style="margin: 4px 0; font-size: 14px;">456 Explorer Avenue</p>
            <p style="margin: 4px 0; font-size: 14px;">Cape Town, 8001</p>
            <p style="margin: 4px 0; font-size: 14px;">South Africa</p>
            <p style="margin: 8px 0 0 0; font-size: 14px;"><strong>Phone:</strong> +27 (21) 123-4567</p>
        </div>
    `);

    // Add circle to show service area (optional)
    L.circle([-26.2041, 28.0473], {
        color: '#22c55e',
        fillColor: '#22c55e',
        fillOpacity: 0.1,
        radius: 500000 // 500km radius
    }).addTo(map);

    // Fit map to show both markers
    const group = new L.featureGroup([johannesburgOffice, capeTownOffice]);
    map.fitBounds(group.getBounds().pad(0.2));
}

// Alternative: Simple map using Google Maps Embed API (if Leaflet fails)
function createSimpleMap(container) {
    const placeholder = container.querySelector('.map-placeholder');
    if (placeholder) {
        placeholder.innerHTML = `
            <iframe 
                width="100%" 
                height="400" 
                style="border:0; border-radius: 12px;" 
                loading="lazy" 
                allowfullscreen
                referrerpolicy="no-referrer-when-downgrade"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3580.1234567890!2d28.0473!3d-26.2041!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjbCsDEyJzE0LjgiUyAyOMKwMDInNTAuMyJF!5e0!3m2!1sen!2sza!4v1234567890123!5m2!1sen!2sza">
            </iframe>
        `;
    }
}

