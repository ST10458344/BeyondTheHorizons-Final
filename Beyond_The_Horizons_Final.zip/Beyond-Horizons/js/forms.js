/* ============================================
   Beyond The Horizons - Form Validation
   Part 3: Form Functionality and Validation
   ============================================ */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize enquiry form validation
    const enquiryForm = document.getElementById('bookingForm');
    if (enquiryForm) {
        initEnquiryForm(enquiryForm);
    }

    // Initialize contact form validation
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        initContactForm(contactForm);
    }
});

/* ============================================
   ENQUIRY FORM VALIDATION & PROCESSING
   ============================================ */
function initEnquiryForm(form) {
    form.addEventListener('submit', function(e) {
        e.preventDefault();

        // Clear previous errors
        clearErrors(form);

        // Validate all fields
        const isValid = validateEnquiryForm(form);

        if (isValid) {
            // Process form data
            processEnquiryForm(form);
        }
    });

    // Real-time validation
    const fields = form.querySelectorAll('input, select, textarea');
    fields.forEach(field => {
        field.addEventListener('blur', function() {
            validateField(this);
        });

        field.addEventListener('input', function() {
            if (this.classList.contains('error')) {
                validateField(this);
            }
        });
    });

    // Date validation
    const departureDate = form.querySelector('#departureDate');
    const returnDate = form.querySelector('#returnDate');

    if (departureDate && returnDate) {
        departureDate.addEventListener('change', function() {
            validateDates(departureDate, returnDate);
        });

        returnDate.addEventListener('change', function() {
            validateDates(departureDate, returnDate);
        });
    }

    // Show/hide other destination field
    const destinationSelect = form.querySelector('#destination');
    const otherDestination = form.querySelector('#otherDestination');

    if (destinationSelect && otherDestination) {
        destinationSelect.addEventListener('change', function() {
            if (this.value === 'other') {
                otherDestination.style.display = 'block';
                otherDestination.setAttribute('required', 'required');
            } else {
                otherDestination.style.display = 'none';
                otherDestination.removeAttribute('required');
                otherDestination.value = '';
            }
        });
    }
}

function validateEnquiryForm(form) {
    let isValid = true;

    // Required fields
    const requiredFields = [
        { id: 'firstName', name: 'First Name' },
        { id: 'lastName', name: 'Last Name' },
        { id: 'email', name: 'Email Address' },
        { id: 'groupSize', name: 'Group Size' },
        { id: 'destination', name: 'Preferred Destination' },
        { id: 'departureDate', name: 'Departure Date' },
        { id: 'returnDate', name: 'Return Date' },
        { id: 'tripType', name: 'Type of Trip' }
    ];

    requiredFields.forEach(field => {
        const input = form.querySelector(`#${field.id}`);
        if (input && !validateField(input)) {
            isValid = false;
        }
    });

    // Validate email format
    const email = form.querySelector('#email');
    if (email && email.value) {
        if (!validateEmail(email.value)) {
            showError(email, 'Please enter a valid email address');
            isValid = false;
        }
    }

    // Validate phone if provided
    const phone = form.querySelector('#phone');
    if (phone && phone.value) {
        if (!validatePhone(phone.value)) {
            showError(phone, 'Please enter a valid phone number (e.g., +27 11 123 4567)');
            isValid = false;
        }
    }

    // Validate dates
    const departureDate = form.querySelector('#departureDate');
    const returnDate = form.querySelector('#returnDate');
    if (departureDate && returnDate) {
        if (!validateDates(departureDate, returnDate)) {
            isValid = false;
        }
    }

    // Validate other destination if selected
    const destination = form.querySelector('#destination');
    const otherDestination = form.querySelector('#otherDestination');
    if (destination && destination.value === 'other') {
        if (!otherDestination || !otherDestination.value.trim()) {
            showError(otherDestination, 'Please specify the destination');
            isValid = false;
        }
    }

    return isValid;
}

function processEnquiryForm(form) {
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());

    // Get checkbox values
    const preferredContact = form.querySelectorAll('input[name="preferredContact"]:checked');
    data.preferredContact = Array.from(preferredContact).map(cb => cb.value).join(', ');

    // Show loading state
    const submitButton = form.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    submitButton.textContent = 'Processing...';
    submitButton.disabled = true;

    // Simulate processing (in real app, this would be an AJAX call)
    setTimeout(() => {
        // Calculate estimated cost based on selections
        const response = generateEnquiryResponse(data);

        // Display response
        displayEnquiryResponse(response, form);

        // Reset button
        submitButton.textContent = originalText;
        submitButton.disabled = false;
    }, 1500);
}

function generateEnquiryResponse(data) {
    // Calculate estimated pricing
    const destination = data.destination;
    const groupSize = data.groupSize;
    const budget = data.budget;
    const accommodationType = data.accommodationType || 'hotel';
    const tripType = data.tripType;

    // Base prices (per person)
    const basePrices = {
        'bali': 16500,
        'paris': 24000,
        'tokyo': 22000,
        'newyork': 14800,
        'santorini': 20300,
        'costarica': 18400,
        'other': 20000
    };

    let basePrice = basePrices[destination] || 20000;

    // Group discounts
    let discount = 0;
    if (groupSize === '5-6') discount = 0.10;
    if (groupSize === '7-10') discount = 0.15;
    if (groupSize === '10+') discount = 0.20;

    // Accommodation multipliers
    const accommodationMultipliers = {
        'hotel': 1.0,
        'resort': 1.3,
        'vacation-rental': 1.2,
        'all-inclusive': 1.5,
        'boutique': 1.4,
        'hostel': 0.7
    };

    const multiplier = accommodationMultipliers[accommodationType] || 1.0;
    basePrice *= multiplier;

    // Apply discount
    const discountedPrice = basePrice * (1 - discount);
    const totalPrice = discountedPrice;

    // Availability check (simulated)
    const availability = Math.random() > 0.3 ? 'Available' : 'Limited availability';

    return {
        destination: data.destination,
        groupSize: data.groupSize,
        departureDate: data.departureDate,
        returnDate: data.returnDate,
        estimatedPrice: totalPrice,
        availability: availability,
        message: `Thank you for your enquiry! Based on your selections, we have ${availability.toLowerCase()} for your trip. Estimated cost per person: R${totalPrice.toLocaleString('en-ZA', {minimumFractionDigits: 2, maximumFractionDigits: 2})}. Our travel specialist will contact you within 24 hours with a detailed quote and itinerary.`
    };
}

function displayEnquiryResponse(response, form) {
    // Create response modal
    const responseHTML = `
        <div class="form-response">
            <h3>Enquiry Submitted Successfully!</h3>
            <div class="response-details">
                <p><strong>Destination:</strong> ${response.destination}</p>
                <p><strong>Group Size:</strong> ${response.groupSize}</p>
                <p><strong>Departure:</strong> ${formatDate(response.departureDate)}</p>
                <p><strong>Return:</strong> ${formatDate(response.returnDate)}</p>
                <p><strong>Estimated Price per Person:</strong> R${response.estimatedPrice.toLocaleString('en-ZA', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</p>
                <p><strong>Availability:</strong> ${response.availability}</p>
            </div>
            <p class="response-message">${response.message}</p>
            <button onclick="this.closest('.modal-overlay').classList.remove('active'); document.body.style.overflow='';" class="submit-button">Close</button>
        </div>
    `;

    if (typeof openModal === 'function') {
        openModal(responseHTML);
    } else {
        alert(response.message);
    }

    // Reset form
    form.reset();
}

/* ============================================
   CONTACT FORM VALIDATION & PROCESSING
   ============================================ */
function initContactForm(form) {
    form.addEventListener('submit', function(e) {
        e.preventDefault();

        // Clear previous errors
        clearErrors(form);

        // Validate all fields
        const isValid = validateContactForm(form);

        if (isValid) {
            // Process form data
            processContactForm(form);
        }
    });

    // Real-time validation
    const fields = form.querySelectorAll('input, select, textarea');
    fields.forEach(field => {
        field.addEventListener('blur', function() {
            validateField(this);
        });

        field.addEventListener('input', function() {
            if (this.classList.contains('error')) {
                validateField(this);
            }
        });
    });
}

function validateContactForm(form) {
    let isValid = true;

    // Required fields
    const requiredFields = [
        { id: 'firstName', name: 'First Name' },
        { id: 'lastName', name: 'Last Name' },
        { id: 'contactEmail', name: 'Email Address' },
        { id: 'subject', name: 'Subject' },
        { id: 'contactMessage', name: 'Message' }
    ];

    requiredFields.forEach(field => {
        const input = form.querySelector(`#${field.id}`);
        if (input && !validateField(input)) {
            isValid = false;
        }
    });

    // Validate email format
    const email = form.querySelector('#contactEmail');
    if (email && email.value) {
        if (!validateEmail(email.value)) {
            showError(email, 'Please enter a valid email address');
            isValid = false;
        }
    }

    // Validate phone if provided
    const phone = form.querySelector('#contactPhone');
    if (phone && phone.value) {
        if (!validatePhone(phone.value)) {
            showError(phone, 'Please enter a valid phone number');
            isValid = false;
        }
    }

    // Validate message length
    const message = form.querySelector('#contactMessage');
    if (message && message.value) {
        if (message.value.trim().length < 10) {
            showError(message, 'Message must be at least 10 characters long');
            isValid = false;
        }
        if (message.value.length > 1000) {
            showError(message, 'Message must be less than 1000 characters');
            isValid = false;
        }
    }

    return isValid;
}

function processContactForm(form) {
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());

    // Show loading state
    const submitButton = form.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    submitButton.textContent = 'Sending...';
    submitButton.disabled = true;

    // Simulate email sending (in real app, this would be an AJAX call)
    setTimeout(() => {
        // Compile email content
        const emailContent = compileEmail(data);

        // Display success message
        displayContactResponse(emailContent, form);

        // Reset button
        submitButton.textContent = originalText;
        submitButton.disabled = false;
    }, 1500);
}

function compileEmail(data) {
    const recipient = 'info@beyondthehorizons.com';
    const subject = `Contact Form: ${data.subject}`;
    
    const body = `
New Contact Form Submission

From: ${data.firstName} ${data.lastName}
Email: ${data.contactEmail}
Phone: ${data.contactPhone || 'Not provided'}

Subject: ${data.subject}

Message:
${data.contactMessage}

---
This email was generated from the contact form on Beyond The Horizons website.
    `.trim();

    return {
        recipient: recipient,
        subject: subject,
        body: body,
        mailtoLink: `mailto:${recipient}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
    };
}

function displayContactResponse(emailData, form) {
    const responseHTML = `
        <div class="form-response">
            <h3>Message Sent Successfully!</h3>
            <p>Your message has been prepared and is ready to send.</p>
            <div class="response-details">
                <p><strong>To:</strong> ${emailData.recipient}</p>
                <p><strong>Subject:</strong> ${emailData.subject}</p>
            </div>
            <p class="response-message">In a production environment, this would be sent automatically. For now, you can copy the details or use the mailto link below.</p>
            <div class="response-actions">
                <a href="${emailData.mailtoLink}" class="submit-button" style="display: inline-block; margin-right: 10px;">Open in Email Client</a>
                <button onclick="copyToClipboard(\`${emailData.body.replace(/`/g, '\\`')}\`)" class="submit-button" style="display: inline-block;">Copy Message</button>
            </div>
            <button onclick="this.closest('.modal-overlay').classList.remove('active'); document.body.style.overflow='';" class="submit-button" style="margin-top: 10px;">Close</button>
        </div>
    `;

    if (typeof openModal === 'function') {
        openModal(responseHTML);
    } else {
        alert('Thank you for your message! We will get back to you soon.');
    }

    // Reset form
    form.reset();
}

/* ============================================
   VALIDATION HELPERS
   ============================================ */
function validateField(field) {
    const value = field.value.trim();
    const fieldName = field.previousElementSibling?.textContent || field.name;

    // Check required
    if (field.hasAttribute('required') && !value) {
        showError(field, `${fieldName} is required`);
        return false;
    }

    // Email validation
    if (field.type === 'email' && value) {
        if (!validateEmail(value)) {
            showError(field, 'Please enter a valid email address');
            return false;
        }
    }

    // Phone validation
    if (field.type === 'tel' && value) {
        if (!validatePhone(value)) {
            showError(field, 'Please enter a valid phone number');
            return false;
        }
    }

    // Clear error if valid
    clearError(field);
    return true;
}

function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function validatePhone(phone) {
    // Accepts various formats: +27 11 123 4567, 011 123 4567, etc.
    const phoneRegex = /^[\+]?[(]?[0-9]{1,4}[)]?[-\s\.]?[(]?[0-9]{1,4}[)]?[-\s\.]?[0-9]{1,9}$/;
    return phoneRegex.test(phone.replace(/\s/g, ''));
}

function validateDates(departureDate, returnDate) {
    if (!departureDate.value || !returnDate.value) {
        return true; // Let required validation handle empty dates
    }

    const departure = new Date(departureDate.value);
    const returnDateObj = new Date(returnDate.value);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Check if departure is in the past
    if (departure < today) {
        showError(departureDate, 'Departure date cannot be in the past');
        return false;
    }

    // Check if return is before departure
    if (returnDateObj <= departure) {
        showError(returnDate, 'Return date must be after departure date');
        return false;
    }

    clearError(departureDate);
    clearError(returnDate);
    return true;
}

function showError(field, message) {
    clearError(field);
    field.classList.add('error');
    
    const errorElement = document.createElement('span');
    errorElement.className = 'error-message';
    errorElement.textContent = message;
    errorElement.setAttribute('role', 'alert');
    
    field.parentElement.appendChild(errorElement);
}

function clearError(field) {
    field.classList.remove('error');
    const errorElement = field.parentElement.querySelector('.error-message');
    if (errorElement) {
        errorElement.remove();
    }
}

function clearErrors(form) {
    const errorFields = form.querySelectorAll('.error');
    errorFields.forEach(field => clearError(field));
}

function formatDate(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-ZA', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

// Copy to clipboard helper
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        alert('Message copied to clipboard!');
    }).catch(() => {
        alert('Failed to copy. Please copy manually.');
    });
}

